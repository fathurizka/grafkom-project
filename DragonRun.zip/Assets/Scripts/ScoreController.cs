﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ScoreController : MonoBehaviour
{
     public static int scoreValue = 0;
     public static int highScoreValue = 0;
     public int highScoreCount;
     public Text score;
     public Text highScore;
     // Start is called before the first frame update
     void Start()
     {
        //  score = GetComponent<Text>();
        if(PlayerPrefs.HasKey("HighScore")){
            highScoreCount=PlayerPrefs.GetInt("HighScore");
        }
     }
 
     // Update is called once per frame
     void Update()
     {
         score.text = "" + scoreValue;
         if(highScoreCount<scoreValue){
             highScoreCount=scoreValue;
             PlayerPrefs.SetInt("HighScore", highScoreCount);
         }
        highScore.text = "" + highScoreCount;
     }
}
