﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TreesGenerator : MonoBehaviour
{
    public GameObject Block;
    public Transform generationPoint;
    public float distanceBetween;

    private float platformWidth=1.95f;
    public float minDistance;
    public float maxDistance;

    // public GameObject[] Blocks;
    private int platformSelector;

    public ObjectPooler[] theObjectPools;

    // Start is called before the first frame update
    void Start()
    {
        // platformWidth = 54.95;
        // platformWidth = theObjectPools.pooledObject.GetComponent<CapsuleCollider2D>().size.x;
        //distanceBetween = platformWidth;
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.x < generationPoint.position.x)
        {
            distanceBetween = Random.Range(minDistance, maxDistance);
            transform.position = new Vector3(transform.position.x + platformWidth + distanceBetween, transform.position.y, transform.position.z);

            platformSelector = Random.Range(0, /*Blocks*/theObjectPools.Length);

            // Instantiate(Blocks[platformSelector], transform.position, transform.rotation);
            // Instantiate(Block, transform.position, transform.rotation);
            GameObject newBlock = theObjectPools[platformSelector].GetPooledObject();
            newBlock.transform.position = transform.position;
            newBlock.transform.rotation = transform.rotation;
            newBlock.SetActive(true);
        }
    }
}
