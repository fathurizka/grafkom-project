﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class HeartController : MonoBehaviour
{
     public static int heartValue = 5;
     Text heart;
     // Start is called before the first frame update
     void Start()
     {
         heart = GetComponent<Text>();
     }
 
     // Update is called once per frame
     void Update()
     {
         heart.text = "" + heartValue;
     }
}
