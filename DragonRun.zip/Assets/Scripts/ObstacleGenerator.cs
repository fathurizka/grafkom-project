﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleGenerator : MonoBehaviour
{
    public GameObject Block;
    public Transform generationPoint;
    public float distanceBetween;

    private float platformWidth;
    public float minDistance;
    public float maxDistance;

    // public GameObject[] Blocks;
    private int platformSelector;

    public ObjectPooler[] theObjectPools;

    // Start is called before the first frame update
    void Start()
    {
        platformWidth = Block.GetComponent<BoxCollider2D>().size.x;
        // platformWidth = theObjectPools.pooledObject.GetComponent<CapsuleCollider2D>().size.x;
        //distanceBetween = platformWidth;
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.x < generationPoint.position.x)
        {
            distanceBetween = Random.Range(minDistance, maxDistance);
            platformSelector = Random.Range(0, /*Blocks*/theObjectPools.Length);
            transform.position = new Vector3(transform.position.x + platformWidth + distanceBetween, transform.position.y, transform.position.z);


            // Instantiate(Blocks[platformSelector], transform.position, transform.rotation);
            // Instantiate(Block, transform.position, transform.rotation);
            GameObject newBlock = theObjectPools[platformSelector].GetPooledObject();
            newBlock.transform.position = transform.position;
            newBlock.transform.rotation = transform.rotation;
            newBlock.SetActive(true);
        }
    }
}
