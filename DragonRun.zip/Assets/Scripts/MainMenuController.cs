﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuController : MonoBehaviour
{
    public void LoadGame (string input)
    {
        GameController.isPlay = true;
        SceneManager.LoadScene("AppScene");
    }
    public void QuitGame (string input)
    {
        GameController.isPlay = true;
        SceneManager.LoadScene("MenuScene");
    }
}
