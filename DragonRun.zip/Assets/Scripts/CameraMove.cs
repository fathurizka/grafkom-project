﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CameraMove : MonoBehaviour
{
    private List<GameObject> MyGameObjects = new List<GameObject>();
    // Properti untuk player
    public float movePower = 10f;
    public bool playButton = false;
    public bool playerRunning = false;
    private Rigidbody2D rb;
    // private Animator anim;
    Vector3 movement;
    private int direction = 1;
    // bool isJumping = false;
    // Start is called before the first frame update
    void Start()
    {
        playButton = GameController.isPlay;
        rb=GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 moveVelocity= Vector3.zero;
        // anim.SetBool("isRunning",false);
        // if (Input.GetAxisRaw("Horizontal")<0){
        //     direction= -1;
        //     moveVelocity = Vector3.left;
        //
        //     transform.localScale = new Vector3(direction,1,1);
        //     anim.SetBool("isRunning",true);
        //
        // }
        // if( Input.GetAxisRaw("Horizontal")>0)
        if (playerRunning)
        {
            direction = 1;
            moveVelocity = Vector3.right;
            transform.localScale = new Vector3(direction,1,1);
            // anim.SetBool("isRunning",true);

        transform.position += moveVelocity*movePower*Time.deltaTime;
        }
    }
}
