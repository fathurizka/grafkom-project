﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformGenerator : MonoBehaviour
{
    public GameObject Block;
    public Transform generationPoint;
    public float distanceBetween;

    private float platformWidth;

    public ObjectPooler theObjectPool;

    // Start is called before the first frame update
    void Start()
    {
        platformWidth = Block.GetComponent<BoxCollider2D>().size.x;
        //distanceBetween = platformWidth;
    }

    // Update is called once per frame
    void Update()
    {
        if(transform.position.x < generationPoint.position.x)
        {
            transform.position = new Vector3(transform.position.x + platformWidth + distanceBetween, transform.position.y, transform.position.z);
            //Instantiate(Block, transform.position, transform.rotation);
            GameObject newBlock = theObjectPool.GetPooledObject();
            newBlock.transform.position = transform.position;
            newBlock.transform.rotation = transform.rotation;
            newBlock.SetActive(true);
        }
    }
}
