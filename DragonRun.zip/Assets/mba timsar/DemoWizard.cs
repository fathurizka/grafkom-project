﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class DemoWizard : MonoBehaviour
{
    
    private List<GameObject> MyGameObjects = new List<GameObject>();
    // Properti untuk player
    public int heart = 0;
    public int energy = 0;
    public int points = 0;
    public float movePower = 10f;
    public float jumpPower = 22f;
    public bool playButton = false;
    public bool playerRunning = false;
    private Rigidbody2D rb;
    private Animator anim;
    public bool isPowerActive = false;
    Vector3 movement;
    public GameObject energyIconActive;
    private int direction = 1;
    bool isJumping = false;
    
    //sound effect
    private AudioSource soundEffect;
    public AudioClip breakObstacle;
    public AudioClip getScore;

    // SoundEffect soundEffect;

    void Awake(){
        soundEffect = GetComponent<AudioSource>();
    }

    // Start is called before the first frame update
    void Start()
    {
        soundEffect = GetComponent<AudioSource>();
        // Debug.Log(StateController.isPlay);
        playButton = GameController.isPlay;
        rb=GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        // soundEffect = gameObject.GetComponent<SoundEffect>();
    }
    private void FixedUpdate() {
        Jump();
        Run();
        PlayGame();
    }
    private void OnTriggerEnter2D(Collider2D other) { 
        anim.SetBool("isJumping",false);
    }
    void Update()
    {
        // Mengaktifkan energy untuk menghancurkan Block
        if (Input.GetKeyDown("space") || Input.GetMouseButtonDown(1))
        {
            if (EnergyController.energyValue >= 1)
            {
                isPowerActive = isPowerActive == true ? false : true;
                energyIconActive.SetActive(isPowerActive);
                float yy = transform.position.x;
                // energyIconActive.transform.position = new Vector3(-59.7f, -16.2f, -931.8106f);
                // Debug.Log(transform.position.x);
                // Debug.Log(transform.position);
            }
            else
            {
                isPowerActive = false;
            }
        }
    }
    void Run(){
        Vector3 moveVelocity= Vector3.zero;
        anim.SetBool("isRunning",false);
        // if (Input.GetAxisRaw("Horizontal")<0){
        //     direction= -1;
        //     moveVelocity = Vector3.left;
        //
        //     transform.localScale = new Vector3(direction,1,1);
        //     anim.SetBool("isRunning",true);
        //
        // }
        // if( Input.GetAxisRaw("Horizontal")>0)
        if (playerRunning)
        {
            direction = 1;
            moveVelocity = Vector3.right;
            transform.localScale = new Vector3(direction,1,1);
            anim.SetBool("isRunning",true);

        }
        transform.position += moveVelocity*movePower*Time.deltaTime;
    }
    void Jump(){
        if( ( /*Input.GetButtonDown("Jump") ||*/ Input.GetAxisRaw("Vertical")>0 || Input.GetMouseButtonDown(0) )
        &&!anim.GetBool("isJumping")){
            isJumping=true;
            anim.SetTrigger("doJumping");
            anim.SetBool("isJumping",true);
        }
        if(!isJumping){
            return;
        }
        rb.velocity = Vector2.zero;
        Vector2 jumpVelocity = new Vector2(0,jumpPower);
        rb.AddForce(jumpVelocity,ForceMode2D.Impulse);
        isJumping=false;
    }
    
    // Author : Nurul Akbar
    private void PlayGame()
    {
        playerRunning = playButton ? true : false;
    }
    private void ResetGame()
    {
        ScoreResultController.scoreResultValue = ScoreController.scoreValue;
        // Atur Posisi dan Gerak
        transform.position = new Vector3(-17f, 2.5f, 0);
        transform.localScale = new Vector3(1, 1, 1);
        playButton = false;
        // Properti untuk Start Game
		HeartController.heartValue = 5;
		EnergyController.energyValue = 5;
		ScoreController.scoreValue = 0;
		// ScoreController.highScoreCount = ScoreController.highScoreCount;
        // heart = 0;
        // energy = 0;
        points = 0;
        // Mengaktifkan Semua Game Object yang Dinonaktifkan
        foreach (GameObject obj in MyGameObjects)
        {
            // Debug.Log(obj.gameObject.name);
            obj.gameObject.SetActive(true);
        }
        // Tampilkan scene MenuScene
        SceneManager.LoadScene("PlayAgainScene");
    }
    private void OnCollisionEnter2D(Collision2D coll) {
        // Player dan Musuh
        if (coll.gameObject.name == "StoneMonster")
        {
            MyGameObjects.Add(coll.gameObject);
            HeartController.heartValue -= 1;
            
            if (HeartController.heartValue == 0)
            {
                ResetGame();
            }
            coll.gameObject.SetActive(false);
        }
		if (coll.gameObject.name == "DragonSoul"){
			ResetGame();
		}
         // Player dan Score
        if (coll.gameObject.name == "PeopleScore(Clone)" || coll.gameObject.name == "PeopleScore2(Clone)" || coll.gameObject.name == "PeopleScore3(Clone)" || coll.gameObject.name == "PeopleScore4(Clone)" || coll.gameObject.name == "PeopleScore5(Clone)" || coll.gameObject.name == "PeopleScore6(Clone)" || coll.gameObject.name == "PeopleScore7(Clone)")
        {
            MyGameObjects.Add(coll.gameObject);
            // score = 2;
        	ScoreController.scoreValue += 1;
        	// score = 0;
            coll.gameObject.SetActive(false);
            // soundEffect.GetScore();
            soundEffect.clip = getScore;
            soundEffect.Play();
        }
        // Player dan Heart
        if (coll.gameObject.name == "BottleHealth")
        {
            MyGameObjects.Add(coll.gameObject);
            // heart = 2;
			HeartController.heartValue += 2;
			// heart = 0;
            coll.gameObject.SetActive(false);
        }
        // PLayer dan Energy
        if (coll.gameObject.name == "BottleEnergy" || coll.gameObject.name == "BottleEnergy(Clone)")
        {
            MyGameObjects.Add(coll.gameObject);
            // energy = 2;
			EnergyController.energyValue += 2;
			// energy = 0;
            coll.gameObject.SetActive(false);
        }
        // Player dan Batu
        if ((coll.gameObject.name == "Rocks(Clone)"||coll.gameObject.name == "Rocks2(Clone)"||coll.gameObject.name == "Rocks3(Clone)") && (EnergyController.energyValue >= 1 && isPowerActive))
        {
            MyGameObjects.Add(coll.gameObject);
            // energy = 2;
            EnergyController.energyValue -= 1;
            // energy = 0;
            coll.gameObject.SetActive(false);
            // GetComponent<AudioSource>().Play();
            // soundEffect.BreakObstacle();
            soundEffect.clip = breakObstacle;
            soundEffect.Play();
        }
        if ((coll.gameObject.name == "Block(Clone)"||coll.gameObject.name == "Block 1x1(Clone)"||coll.gameObject.name == "Block 4x1(Clone)") && (EnergyController.energyValue >= 1 && isPowerActive))
        {
            MyGameObjects.Add(coll.gameObject);
            // energy = 2;
            EnergyController.energyValue -= 1;
            // energy = 0;
            coll.gameObject.SetActive(false);
            // GetComponent<AudioSource>().Play();
            // soundEffect.BreakObstacle();
            soundEffect.clip = breakObstacle;
            soundEffect.Play();
        }
    } 
}
